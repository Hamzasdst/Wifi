package com.wifiguard.work

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.wifiguard.WiFiGuardApp
import kotlinx.coroutines.CancellationException
import androidx.work.ListenableWorker.Result

/**
 * Runs the periodic check (every ~15 minutes, the WorkManager minimum) and the one-shot
 * check scheduled for each reset time. Both paths run the same idempotent logic.
 */
class UsageCheckWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val container = (applicationContext as WiFiGuardApp).container
        return try {
            container.usageMonitor.runCheck()
            // Re-arm the reset check every run so it survives reboots and changed settings.
            val reset = container.settingsStore.currentSettings().resetTime
            UsageWorkScheduler.scheduleReset(applicationContext, reset)
            Result.success()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.retry()
        }
    }
}
