package com.wifiguard.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val NavyBackground = Color(0xFF0A1224)
val NavySurface = Color(0xFF121D35)
val NavySurfaceHigh = Color(0xFF1B2A4A)
val BlueAccent = Color(0xFF3B82F6)
val CyanAccent = Color(0xFF22D3EE)
val TextPrimary = Color(0xFFE6EEFF)
val TextMuted = Color(0xFF8FA3C7)
val WarningAmber = Color(0xFFF59E0B)
val DangerRose = Color(0xFFF43F5E)

private val WiFiGuardColors = darkColorScheme(
    primary = BlueAccent,
    onPrimary = Color.White,
    secondary = CyanAccent,
    onSecondary = NavyBackground,
    tertiary = CyanAccent,
    background = NavyBackground,
    onBackground = TextPrimary,
    surface = NavySurface,
    onSurface = TextPrimary,
    surfaceVariant = NavySurfaceHigh,
    onSurfaceVariant = TextMuted,
    error = DangerRose,
)

@Composable
fun WiFiGuardTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = WiFiGuardColors, content = content)
}
