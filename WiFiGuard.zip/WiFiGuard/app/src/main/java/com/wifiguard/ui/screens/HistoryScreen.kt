package com.wifiguard.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.wifiguard.domain.ByteFormat
import com.wifiguard.ui.HistoryState
import com.wifiguard.ui.components.DAY_FORMAT
import com.wifiguard.ui.components.GlassCard
import com.wifiguard.ui.components.SHORT_FORMAT
import com.wifiguard.ui.components.StatCard
import com.wifiguard.ui.components.UsageBarChart
import com.wifiguard.ui.theme.TextMuted
import kotlin.math.roundToInt

@Composable
fun HistoryScreen(
    state: HistoryState,
    onShiftDay: (Long) -> Unit,
    modifier: Modifier = Modifier,
) {
    val summary = state.summary
    val point = state.selectedPoint

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text("History", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)

        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            OutlinedButton(onClick = { onShiftDay(-1L) }) { Text("Previous") }
            Text(
                state.selected.format(DAY_FORMAT),
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
            )
            Button(onClick = { onShiftDay(1L) }, enabled = state.canGoForward) { Text("Next") }
        }

        GlassCard(Modifier.fillMaxWidth()) {
            Text("Selected day", style = MaterialTheme.typography.labelMedium, color = TextMuted)
            Text(
                point?.let { ByteFormat.format(it.usedBytes) } ?: "No data recorded",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
            )
            if (point != null) {
                val pct = if (point.limitBytes <= 0L) 0 else ((point.usedBytes * 100f) / point.limitBytes).roundToInt()
                Text(
                    "$pct% of ${ByteFormat.format(point.limitBytes)}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextMuted,
                )
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard("This week", ByteFormat.format(summary?.weeklyBytes ?: 0L), Modifier.weight(1f))
            StatCard("This month", ByteFormat.format(summary?.monthlyBytes ?: 0L), Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard(
                "Daily average",
                ByteFormat.format(summary?.averageBytes ?: 0L),
                Modifier.weight(1f),
            )
            StatCard(
                "Highest day",
                summary?.highest?.let { "${ByteFormat.format(it.usedBytes)} · ${it.date.format(SHORT_FORMAT)}" } ?: "—",
                Modifier.weight(1f),
            )
        }

        GlassCard(Modifier.fillMaxWidth()) {
            Text(
                "14 days to ${state.selected.format(SHORT_FORMAT)}",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
            )
            Spacer(Modifier.height(4.dp))
            UsageBarChart(bars = state.chart, limitBytes = state.limitBytes)
        }
    }
}
