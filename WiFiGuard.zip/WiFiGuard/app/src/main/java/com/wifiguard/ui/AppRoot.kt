package com.wifiguard.ui

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Settings as SettingsIcon
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.wifiguard.domain.DataUnit
import com.wifiguard.ui.screens.AboutScreen
import com.wifiguard.ui.screens.AlertsScreen
import com.wifiguard.ui.screens.DashboardScreen
import com.wifiguard.ui.screens.HistoryScreen
import com.wifiguard.ui.screens.SettingsScreen

private enum class Destination(val route: String, val label: String, val icon: ImageVector) {
    DASHBOARD("dashboard", "Dashboard", Icons.Filled.Home),
    HISTORY("history", "History", Icons.Filled.DateRange),
    ALERTS("alerts", "Alerts", Icons.Filled.Notifications),
    SETTINGS("settings", "Settings", SettingsIcon),
    ABOUT("about", "About", Icons.Filled.Info),
}

@Composable
fun WiFiGuardRoot(vm: MainViewModel = viewModel()) {
    val navController = rememberNavController()
    val backStack by navController.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route
    val context = LocalContext.current

    val dashboard by vm.dashboard.collectAsStateWithLifecycle()
    val history by vm.history.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val firedToday by vm.firedToday.collectAsStateWithLifecycle()

    // Pick up a permission change made in system settings as soon as the user returns.
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { vm.refreshNow() }

    Scaffold(
        containerColor = androidx.compose.material3.MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar {
                Destination.entries.forEach { dest ->
                    NavigationBarItem(
                        selected = currentRoute == dest.route,
                        onClick = {
                            navController.navigate(dest.route) {
                                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(dest.icon, contentDescription = dest.label) },
                        label = { Text(dest.label) },
                    )
                }
            }
        },
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Destination.DASHBOARD.route,
            modifier = Modifier.padding(innerPadding),
        ) {
            composable(Destination.DASHBOARD.route) {
                DashboardScreen(
                    state = dashboard,
                    onGrantUsageAccess = { context.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) },
                )
            }
            composable(Destination.HISTORY.route) {
                HistoryScreen(
                    state = history,
                    onShiftDay = vm::shiftDay,
                )
            }
            composable(Destination.ALERTS.route) {
                AlertsScreen(
                    settings = settings,
                    firedToday = firedToday,
                    onToggleThreshold = vm::toggleThreshold,
                    onAddThreshold = vm::addThreshold,
                    onSetEnabled = vm::setNotificationsEnabled,
                )
            }
            composable(Destination.SETTINGS.route) {
                SettingsScreen(
                    settings = settings,
                    hasUsageAccess = dashboard.snapshot?.hasUsageAccess == true,
                    onSaveLimit = { amount: Double, unit: DataUnit -> vm.saveLimit(amount, unit) },
                    onSaveResetTime = { h, m -> vm.saveResetTime(h, m) },
                )
            }
            composable(Destination.ABOUT.route) {
                AboutScreen()
            }
        }
    }
}
