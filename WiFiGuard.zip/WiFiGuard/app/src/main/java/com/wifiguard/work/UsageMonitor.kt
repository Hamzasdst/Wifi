package com.wifiguard.work

import com.wifiguard.data.SettingsStore
import com.wifiguard.data.UsageRepository
import com.wifiguard.domain.NotificationPolicy
import com.wifiguard.domain.UsageSnapshot
import com.wifiguard.notify.UsageAlertNotifier
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * One monitoring pass: read usage, fill history, store today, and send at most one alert.
 * Used by the background worker and by the app while it is open. A mutex stops two passes
 * from both deciding to send the same alert.
 */
class UsageMonitor(
    private val repository: UsageRepository,
    private val settingsStore: SettingsStore,
    private val notifier: UsageAlertNotifier,
) {
    private val mutex = Mutex()

    suspend fun runCheck(now: Long = System.currentTimeMillis()): UsageSnapshot = mutex.withLock {
        val settings = settingsStore.currentSettings()
        val snapshot = repository.snapshot(now, settings)

        repository.backfillHistory(now, settings)
        repository.recordLive(snapshot)

        val used = snapshot.usedBytes ?: return@withLock snapshot

        // A new period has a new key, so earlier fired thresholds no longer apply.
        val fired = settingsStore.currentFired()
        val alreadyFired = if (fired.period == snapshot.window.key) fired.thresholds else emptySet()

        val decision = NotificationPolicy.evaluate(
            usedBytes = used,
            limitBytes = snapshot.limitBytes,
            thresholds = settings.thresholdPercents,
            alreadyFired = alreadyFired,
        )

        // If the alert cannot be shown, leave the fired set unchanged so the next pass retries.
        val alertHandled = when {
            !settings.notificationsEnabled -> true
            decision.alertThreshold == null -> true
            else -> notifier.showUsageAlert(decision.alertThreshold, used, snapshot.limitBytes)
        }

        if (alertHandled) {
            settingsStore.saveFired(snapshot.window.key, alreadyFired + decision.crossed)
        }
        snapshot
    }
}
