package com.wifiguard

import android.app.Application
import android.content.Context
import com.wifiguard.data.SettingsStore
import com.wifiguard.data.UsageRepository
import com.wifiguard.data.local.UsageDatabase
import com.wifiguard.network.WifiUsageReader
import com.wifiguard.notify.UsageAlertNotifier
import com.wifiguard.work.UsageMonitor
import com.wifiguard.work.UsageWorkScheduler

class WiFiGuardApp : Application() {

    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        container.notifier.createChannel()
        UsageWorkScheduler.ensurePeriodic(this)
    }
}

/** Manual dependency wiring: one instance of each layer per process. */
class AppContainer(context: Context) {
    val settingsStore = SettingsStore(context)
    private val database = UsageDatabase.build(context)
    private val reader = WifiUsageReader(context)
    val repository = UsageRepository(settingsStore, database.dailyUsageDao(), reader)
    val notifier = UsageAlertNotifier(context)
    val usageMonitor = UsageMonitor(repository, settingsStore, notifier)
}
