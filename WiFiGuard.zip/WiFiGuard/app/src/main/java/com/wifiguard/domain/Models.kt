package com.wifiguard.domain

import java.time.LocalDate

/** Units the user can pick for the daily limit. Binary (1 GB = 1024 MB). */
enum class DataUnit(val bytesPerUnit: Long, val label: String) {
    MB(1024L * 1024L, "MB"),
    GB(1024L * 1024L * 1024L, "GB"),
}

/** Local wall-clock time at which the daily Wi-Fi period starts. */
data class ResetTime(val hour: Int, val minute: Int) {
    init {
        require(hour in 0..23 && minute in 0..59) { "Invalid reset time $hour:$minute" }
    }

    override fun toString(): String = "%02d:%02d".format(hour, minute)
}

data class WifiGuardSettings(
    val limitAmount: Double = 4.0,
    val limitUnit: DataUnit = DataUnit.GB,
    val thresholdPercents: Set<Int> = setOf(80, 100),
    val resetTime: ResetTime = ResetTime(0, 0),
    val notificationsEnabled: Boolean = true,
) {
    val limitBytes: Long get() = (limitAmount * limitUnit.bytesPerUnit).toLong()
}

/** The daily period that contains a given instant. [key] is the local date the period starts on. */
data class PeriodWindow(
    val key: String,
    val startMs: Long,
    val nextResetMs: Long,
)

/**
 * Point-in-time reading. [usedBytes] is null when Android cannot provide Wi-Fi statistics,
 * so the UI can say "unavailable" instead of showing a misleading zero.
 */
data class UsageSnapshot(
    val window: PeriodWindow,
    val usedBytes: Long?,
    val limitBytes: Long,
    val hasUsageAccess: Boolean,
    val wifiConnected: Boolean,
    val takenAtMs: Long,
)

data class DailyPoint(
    val date: LocalDate,
    val usedBytes: Long,
    val limitBytes: Long,
)
