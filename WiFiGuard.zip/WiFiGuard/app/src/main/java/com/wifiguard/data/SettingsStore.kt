package com.wifiguard.data

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.wifiguard.domain.DataUnit
import com.wifiguard.domain.ResetTime
import com.wifiguard.domain.WifiGuardSettings
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.settingsDataStore by preferencesDataStore(name = "wifiguard_settings")

/** Which threshold alerts were already sent during [period] (the period's start date). */
data class FiredState(val period: String?, val thresholds: Set<Int>)

class SettingsStore(context: Context) {

    private val store = context.settingsDataStore

    private object Keys {
        val LIMIT_AMOUNT = doublePreferencesKey("limit_amount")
        val LIMIT_UNIT = stringPreferencesKey("limit_unit")
        val THRESHOLDS = stringSetPreferencesKey("thresholds")
        val RESET_HOUR = intPreferencesKey("reset_hour")
        val RESET_MINUTE = intPreferencesKey("reset_minute")
        val NOTIFY = booleanPreferencesKey("notifications_enabled")
        val FIRED_PERIOD = stringPreferencesKey("fired_period")
        val FIRED_THRESHOLDS = stringSetPreferencesKey("fired_thresholds")
    }

    val settings: Flow<WifiGuardSettings> = store.data.map { it.toSettings() }

    val fired: Flow<FiredState> = store.data.map { p ->
        FiredState(
            period = p[Keys.FIRED_PERIOD],
            thresholds = p[Keys.FIRED_THRESHOLDS]?.mapNotNull { it.toIntOrNull() }?.toSet() ?: emptySet(),
        )
    }

    suspend fun currentSettings(): WifiGuardSettings = settings.first()

    suspend fun currentFired(): FiredState = fired.first()

    suspend fun update(transform: (WifiGuardSettings) -> WifiGuardSettings) {
        store.edit { prefs ->
            val updated = transform(prefs.toSettings())
            prefs[Keys.LIMIT_AMOUNT] = updated.limitAmount
            prefs[Keys.LIMIT_UNIT] = updated.limitUnit.name
            prefs[Keys.THRESHOLDS] = updated.thresholdPercents.map { it.toString() }.toSet()
            prefs[Keys.RESET_HOUR] = updated.resetTime.hour
            prefs[Keys.RESET_MINUTE] = updated.resetTime.minute
            prefs[Keys.NOTIFY] = updated.notificationsEnabled
        }
    }

    suspend fun saveFired(period: String, thresholds: Set<Int>) {
        store.edit { prefs ->
            prefs[Keys.FIRED_PERIOD] = period
            prefs[Keys.FIRED_THRESHOLDS] = thresholds.map { it.toString() }.toSet()
        }
    }

    private fun Preferences.toSettings(): WifiGuardSettings {
        val defaults = WifiGuardSettings()
        return WifiGuardSettings(
            limitAmount = this[Keys.LIMIT_AMOUNT] ?: defaults.limitAmount,
            limitUnit = this[Keys.LIMIT_UNIT]
                ?.let { runCatching { DataUnit.valueOf(it) }.getOrNull() }
                ?: defaults.limitUnit,
            thresholdPercents = this[Keys.THRESHOLDS]
                ?.mapNotNull { it.toIntOrNull() }
                ?.toSet()
                ?: defaults.thresholdPercents,
            resetTime = ResetTime(this[Keys.RESET_HOUR] ?: 0, this[Keys.RESET_MINUTE] ?: 0),
            notificationsEnabled = this[Keys.NOTIFY] ?: defaults.notificationsEnabled,
        )
    }
}
