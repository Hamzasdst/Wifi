package com.wifiguard.work

import android.content.Context
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.wifiguard.domain.PeriodCalculator
import com.wifiguard.domain.ResetTime
import java.time.ZoneId
import java.util.concurrent.TimeUnit

/**
 * WorkManager jobs survive reboots and app restarts. Android may still delay them under
 * Doze and battery restrictions, so the dashboard recalculates usage whenever it is opened.
 */
object UsageWorkScheduler {

    private const val PERIODIC_NAME = "wifiguard_periodic_check"
    private const val RESET_NAME = "wifiguard_reset_check"

    fun ensurePeriodic(context: Context) {
        val request = PeriodicWorkRequestBuilder<UsageCheckWorker>(15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            PERIODIC_NAME,
            ExistingPeriodicWorkPolicy.KEEP,
            request,
        )
    }

    /** Schedules a check just after the next reset. REPLACE keeps only one pending reset job. */
    fun scheduleReset(context: Context, reset: ResetTime, nowMs: Long = System.currentTimeMillis()) {
        val window = PeriodCalculator.window(nowMs, reset, ZoneId.systemDefault())
        val delayMs = (window.nextResetMs - nowMs).coerceAtLeast(0L) + RESET_GRACE_MS
        val request = OneTimeWorkRequestBuilder<UsageCheckWorker>()
            .setInitialDelay(delayMs, TimeUnit.MILLISECONDS)
            .build()
        WorkManager.getInstance(context).enqueueUniqueWork(
            RESET_NAME,
            ExistingWorkPolicy.REPLACE,
            request,
        )
    }

    private const val RESET_GRACE_MS = 1_000L
}
