package com.wifiguard.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.wifiguard.domain.ByteFormat
import com.wifiguard.ui.MainViewModel
import com.wifiguard.ui.DashboardState
import com.wifiguard.ui.components.CircularUsageIndicator
import com.wifiguard.ui.components.GlassCard
import com.wifiguard.ui.components.StatCard
import com.wifiguard.ui.components.UsageBarChart
import com.wifiguard.ui.components.formatCountdown
import com.wifiguard.ui.theme.CyanAccent
import com.wifiguard.ui.theme.TextMuted
import com.wifiguard.ui.theme.WarningAmber
import kotlin.math.roundToInt

@Composable
fun DashboardScreen(
    state: DashboardState,
    onGrantUsageAccess: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val snap = state.snapshot
    val limit = snap?.limitBytes ?: state.settings.limitBytes
    val used = snap?.usedBytes
    val fraction = if (used == null || limit <= 0L) 0f else used.toFloat() / limit.toFloat()
    val percent = (fraction * 100f).roundToInt()
    val remaining = used?.let { (limit - it).coerceAtLeast(0L) }
    val resetIn = snap?.let { formatCountdown(it.window.nextResetMs - System.currentTimeMillis()) } ?: "—"

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text("WiFiGuard", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        ConnectionChip(connected = snap?.wifiConnected == true)

        if (snap != null && !snap.hasUsageAccess) {
            UsageAccessCard(onGrantUsageAccess)
        }

        GlassCard(Modifier.fillMaxWidth()) {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                CircularUsageIndicator(fraction = fraction, diameter = 210.dp) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = if (used == null) "--" else "$percent%",
                            style = MaterialTheme.typography.displaySmall,
                            fontWeight = FontWeight.Bold,
                        )
                        Text(
                            text = if (used == null) "Wi-Fi data unavailable" else "of daily allowance",
                            style = MaterialTheme.typography.labelMedium,
                            color = TextMuted,
                        )
                    }
                }
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard("Today's usage", used?.let { ByteFormat.format(it) } ?: "—", Modifier.weight(1f))
            StatCard("Daily limit", ByteFormat.format(limit), Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard("Remaining", remaining?.let { ByteFormat.format(it) } ?: "—", Modifier.weight(1f))
            StatCard("Resets in", resetIn, Modifier.weight(1f))
        }

        GlassCard(Modifier.fillMaxWidth()) {
            Text("Last 7 days", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            UsageBarChart(bars = state.recent, limitBytes = limit)
        }

        Text(
            "Android publishes Wi-Fi totals with a delay, so figures can lag by up to a few hours. " +
                "Usage is always recalculated from system timestamps when this screen opens.",
            style = MaterialTheme.typography.labelSmall,
            color = TextMuted,
        )
    }
}

@Composable
private fun ConnectionChip(connected: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .size(10.dp)
                .background(if (connected) CyanAccent else TextMuted, CircleShape),
        )
        Spacer(Modifier.size(8.dp))
        Text(
            if (connected) "Connected to Wi-Fi" else "Not on Wi-Fi",
            style = MaterialTheme.typography.bodyMedium,
            color = TextMuted,
        )
    }
}

@Composable
private fun UsageAccessCard(onGrant: () -> Unit) {
    GlassCard(Modifier.fillMaxWidth()) {
        Text(
            "Usage access needed",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
            color = WarningAmber,
        )
        Text(
            "WiFiGuard reads Wi-Fi totals from Android's network statistics. " +
                "Turn on Usage access for WiFiGuard to start tracking.",
            style = MaterialTheme.typography.bodyMedium,
            color = TextMuted,
        )
        Button(onClick = onGrant) { Text("Open Usage access") }
    }
}
