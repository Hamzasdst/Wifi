package com.wifiguard.data

import com.wifiguard.data.local.DailyUsageDao
import com.wifiguard.data.local.DailyUsageEntity
import com.wifiguard.domain.DailyPoint
import com.wifiguard.domain.PeriodCalculator
import com.wifiguard.domain.UsageSnapshot
import com.wifiguard.domain.WifiGuardSettings
import com.wifiguard.network.WifiUsageReader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.ZoneId

/**
 * Combines live reads from NetworkStatsManager with the local history table.
 * Usage is always recomputed from timestamps; nothing is incremented or cleared.
 */
class UsageRepository(
    private val settingsStore: SettingsStore,
    private val dao: DailyUsageDao,
    private val reader: WifiUsageReader,
) {

    val settings: Flow<WifiGuardSettings> = settingsStore.settings

    fun observeHistory(): Flow<List<DailyPoint>> =
        dao.observeAll().map { rows ->
            rows.map { DailyPoint(LocalDate.parse(it.dateKey), it.usedBytes, it.limitBytes) }
        }

    /** Usage since the start of the current period, up to [now]. */
    suspend fun snapshot(now: Long, s: WifiGuardSettings): UsageSnapshot = withContext(Dispatchers.IO) {
        val window = PeriodCalculator.window(now, s.resetTime, ZoneId.systemDefault())
        UsageSnapshot(
            window = window,
            usedBytes = reader.wifiBytes(window.startMs, now),
            limitBytes = s.limitBytes,
            hasUsageAccess = reader.hasUsageAccess(),
            wifiConnected = reader.isWifiConnected(),
            takenAtMs = now,
        )
    }

    /** Stores the in-progress day. Skipped when Android could not answer. */
    suspend fun recordLive(snap: UsageSnapshot) = withContext(Dispatchers.IO) {
        val used = snap.usedBytes ?: return@withContext
        dao.upsert(
            DailyUsageEntity(
                dateKey = snap.window.key,
                usedBytes = used,
                limitBytes = snap.limitBytes,
                finalized = false,
                updatedAtMs = snap.takenAtMs,
            ),
        )
    }

    /**
     * Fills in past days from system statistics. A day is stored as finalized only after
     * [SETTLE_MS] has passed since it ended, so late-published buckets are still picked up.
     * Days recorded before the app was installed are recovered from the system where it
     * still has them. Limits for those days use the current setting.
     */
    suspend fun backfillHistory(now: Long, s: WifiGuardSettings) = withContext(Dispatchers.IO) {
        val zone = ZoneId.systemDefault()
        val today = LocalDate.parse(PeriodCalculator.window(now, s.resetTime, zone).key)
        for (back in 1..HISTORY_DAYS) {
            val day = today.minusDays(back.toLong())
            if (dao.get(day.toString())?.finalized == true) continue

            val start = PeriodCalculator.startOf(day, s.resetTime, zone)
            val end = PeriodCalculator.startOf(day.plusDays(1), s.resetTime, zone)
            val used = reader.wifiBytes(start, end) ?: continue
            dao.upsert(
                DailyUsageEntity(
                    dateKey = day.toString(),
                    usedBytes = used,
                    limitBytes = s.limitBytes,
                    finalized = end + SETTLE_MS <= now,
                    updatedAtMs = now,
                ),
            )
        }
    }

    companion object {
        const val HISTORY_DAYS = 30
        const val SETTLE_MS = 3L * 60L * 60L * 1000L
    }
}
