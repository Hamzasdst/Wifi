package com.wifiguard.network

import android.app.AppOpsManager
import android.app.usage.NetworkStatsManager
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Process
import android.os.RemoteException

/**
 * Thin wrapper over NetworkStatsManager. Only the physical Wi-Fi interface (TYPE_WIFI) is
 * queried, so cellular traffic is never included. A VPN tunnel is counted once, as the
 * encrypted packets that leave the Wi-Fi interface.
 */
class WifiUsageReader(private val context: Context) {

    private val networkStats = context.getSystemService(NetworkStatsManager::class.java)
    private val connectivity = context.getSystemService(ConnectivityManager::class.java)
    private val appOps = context.getSystemService(AppOpsManager::class.java)

    fun hasUsageAccess(): Boolean =
        appOps.unsafeCheckOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            Process.myUid(),
            context.packageName,
        ) == AppOpsManager.MODE_ALLOWED

    /**
     * Wi-Fi bytes (received + transmitted) between [startMs] and [endMs].
     * Returns null when the answer is unknown (no Usage access or a system error), so a
     * failure is never recorded as zero usage.
     */
    @Suppress("DEPRECATION")
    fun wifiBytes(startMs: Long, endMs: Long): Long? {
        if (endMs <= startMs) return 0L
        if (!hasUsageAccess()) return null
        return try {
            val bucket = networkStats.querySummaryForDevice(
                ConnectivityManager.TYPE_WIFI,
                /* subscriberId = */ null,
                startMs,
                endMs,
            )
            bucket.rxBytes + bucket.txBytes
        } catch (e: SecurityException) {
            null
        } catch (e: RemoteException) {
            null
        }
    }

    fun isWifiConnected(): Boolean =
        connectivity.allNetworks.any { network ->
            connectivity.getNetworkCapabilities(network)
                ?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
        }
}
