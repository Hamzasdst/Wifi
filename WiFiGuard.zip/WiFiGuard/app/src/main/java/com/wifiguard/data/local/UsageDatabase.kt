package com.wifiguard.data.local

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

/**
 * One row per daily period. [finalized] is false while the day is still in progress, and also
 * for a day that ended less than the settle window ago, because Android publishes Wi-Fi
 * buckets with a delay.
 */
@Entity(tableName = "daily_usage")
data class DailyUsageEntity(
    @androidx.room.PrimaryKey val dateKey: String,
    val usedBytes: Long,
    val limitBytes: Long,
    val finalized: Boolean,
    val updatedAtMs: Long,
)

@Dao
interface DailyUsageDao {

    @Upsert
    suspend fun upsert(entity: DailyUsageEntity)

    @Query("SELECT * FROM daily_usage WHERE dateKey = :key LIMIT 1")
    suspend fun get(key: String): DailyUsageEntity?

    @Query("SELECT * FROM daily_usage ORDER BY dateKey ASC")
    fun observeAll(): Flow<List<DailyUsageEntity>>
}

@Database(entities = [DailyUsageEntity::class], version = 1, exportSchema = false)
abstract class UsageDatabase : RoomDatabase() {

    abstract fun dailyUsageDao(): DailyUsageDao

    companion object {
        fun build(context: Context): UsageDatabase =
            Room.databaseBuilder(context, UsageDatabase::class.java, "wifiguard.db").build()
    }
}
