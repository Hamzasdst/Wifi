package com.wifiguard

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.enableEdgeToEdge
import androidx.activity.compose.setContent
import com.wifiguard.ui.WiFiGuardRoot
import com.wifiguard.ui.theme.WiFiGuardTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            WiFiGuardTheme {
                WiFiGuardRoot()
            }
        }
    }
}
