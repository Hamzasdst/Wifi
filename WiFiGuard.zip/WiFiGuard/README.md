# WiFiGuard

WiFiGuard tracks how much Wi-Fi data your Android phone uses each day, against a limit you set, and sends a notification when you reach your warning thresholds. It never measures mobile data.

## Status

This source tree was written without an Android SDK, so it has **not** been compiled, run on a device, or signed in the environment that produced it. The pure-Kotlin logic (period boundaries, threshold policy, history summaries) has unit tests in `app/src/test`. Everything else must be built and tested in Android Studio before you rely on it.

## Requirements

- Android Studio Ladybug (2024.2) or newer, with JDK 17
- Android SDK 35 (minimum device: Android 10 / API 29)

## Install and run

1. Open the `WiFiGuard` folder in Android Studio. It will create the Gradle wrapper and sync.
2. Run the `app` configuration on a device or emulator with a Wi-Fi connection.
3. On first launch, go to **Dashboard → Open Usage access** and enable WiFiGuard. Android does not offer this as a normal permission prompt.
4. Go to **Alerts** and allow notifications when prompted (Android 13+).

## Permissions

| Permission | Why | How it is granted |
|---|---|---|
| `PACKAGE_USAGE_STATS` (Usage access) | Required by `NetworkStatsManager` to read Wi-Fi totals | User turns it on in system settings |
| `POST_NOTIFICATIONS` | Show threshold alerts (Android 13+) | Runtime prompt |
| `ACCESS_NETWORK_STATE` | Show whether you are on Wi-Fi | Install-time |

The app does not request `INTERNET`, location, or any account permission.

## How usage is calculated

- Usage for the current day is `NetworkStatsManager.querySummaryForDevice(TYPE_WIFI, …)` between the most recent reset time and now, summing received and transmitted bytes.
- Nothing is incremented or cleared. Each reading is recomputed from timestamps, so a restart, a missed background job, or a time-zone change cannot double-count or double-reset.
- Completed days are stored in a local Room database. Days from before the app was installed are recovered from system statistics where Android still has them.
- A day is only marked final several hours after it ends, because Android publishes buckets late.
- Alerts are recorded per period. Each threshold fires at most once per period, and several thresholds crossed at once produce a single notification.

## Known limitations

- **Not real-time.** Android publishes network statistics in buckets with a delay, commonly up to a few hours. The dashboard says so.
- **VPN.** Traffic through a VPN is counted as the encrypted packets on the Wi-Fi interface, which includes VPN overhead. It is not counted twice, but totals may differ from what a VPN app reports.
- **History depth.** Android keeps network history for a limited time, so very old days may be unavailable.
- **Background timing.** WorkManager's minimum periodic interval is 15 minutes, and Doze or manufacturer battery rules can delay it. Usage shown on the dashboard is recalculated whenever the app opens or resumes, but threshold alerts can arrive late while the app is closed. Set the app to *Unrestricted* battery use from the Settings screen.
- **Units.** 1 GB is 1024 MB (binary), matching the default 4 GB example in the spec.
- **Backfilled limits.** For days recovered from system statistics, the limit stored is the current setting, not the setting that was active that day.

## Build a signed release APK

1. Create a keystore once, outside the project:
   ```bash
   keytool -genkeypair -v -keystore ~/wifiguard-release.jks -alias wifiguard \
     -keyalg RSA -keysize 4096 -validity 10000
   ```
2. Create `keystore.properties` in the project root (do not commit it):
   ```properties
   storeFile=/absolute/path/to/wifiguard-release.jks
   storePassword=...
   keyAlias=wifiguard
   keyPassword=...
   ```
3. Build:
   ```bash
   ./gradlew assembleRelease
   ```
   The signed APK is at `app/build/outputs/apk/release/app-release.apk`.

Without `keystore.properties`, the release build is unsigned and will not install.

## Tests

```bash
./gradlew testDebugUnitTest
```

Covered: daily period boundaries (custom reset time, exact reset moment, time zones), threshold evaluation (single alert, no duplicates, jump to 100%), and history summaries (weekly, monthly, average, highest day).

Not yet covered by automated tests: Wi-Fi calculation against real `NetworkStatsManager` data, device-restart recovery, and Wi-Fi connect/disconnect transitions. These need an instrumented test or manual testing on a device.

## Architecture

```
com.wifiguard
├── domain/        Pure models and calculations (no Android imports)
├── data/          DataStore settings, repository, Room database
├── network/       NetworkStatsManager and connectivity wrapper
├── notify/        Notification channel and alert builder
├── work/          UsageMonitor (one check), WorkManager worker and scheduler
└── ui/            Compose screens, theme, ViewModel, navigation
```

## Project layout

Gradle Kotlin DSL. Min SDK 29, target and compile SDK 35. Jetpack Compose with Material 3, Room, DataStore Preferences, WorkManager.

## Still to do before release

- Add an app icon review on a real launcher (the current icon is a simple vector)
- Run on Android 10, 13 and 14 with Usage access on, then check that Wi-Fi totals match the system's *Data usage* screen within the expected delay
- Test a device restart, a Wi-Fi disconnect/reconnect, and a VPN session
