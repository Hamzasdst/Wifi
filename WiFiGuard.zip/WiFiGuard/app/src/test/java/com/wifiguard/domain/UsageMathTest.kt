package com.wifiguard.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset

class UsageMathTest {

    private val utc = ZoneOffset.UTC
    private val gb = 1024L * 1024L * 1024L

    private fun ms(iso: String): Long = Instant.parse(iso).toEpochMilli()

    // ---- Daily period boundaries -------------------------------------------------

    @Test
    fun midnightResetPeriodStartsAtLocalMidnight() {
        val w = PeriodCalculator.window(ms("2026-11-18T14:20:00Z"), ResetTime(0, 0), utc)
        assertEquals("2026-11-18", w.key)
        assertEquals(ms("2026-11-18T00:00:00Z"), w.startMs)
        assertEquals(ms("2026-11-19T00:00:00Z"), w.nextResetMs)
    }

    @Test
    fun timeBeforeCustomResetBelongsToPreviousPeriod() {
        val w = PeriodCalculator.window(ms("2026-11-18T04:00:00Z"), ResetTime(6, 0), utc)
        assertEquals("2026-11-17", w.key)
        assertEquals(ms("2026-11-17T06:00:00Z"), w.startMs)
        assertEquals(ms("2026-11-18T06:00:00Z"), w.nextResetMs)
    }

    @Test
    fun exactlyAtResetStartsANewPeriod() {
        val w = PeriodCalculator.window(ms("2026-11-18T06:00:00Z"), ResetTime(6, 0), utc)
        assertEquals("2026-11-18", w.key)
        assertEquals(ms("2026-11-18T06:00:00Z"), w.startMs)
    }

    @Test
    fun timeZoneChangesTheBoundary() {
        // 23:30 UTC is already 01:30 the next day in Cairo (UTC+2 in November).
        val cairo = java.time.ZoneId.of("Africa/Cairo")
        val w = PeriodCalculator.window(ms("2026-11-18T23:30:00Z"), ResetTime(0, 0), cairo)
        assertEquals("2026-11-19", w.key)
    }

    // ---- Threshold alerts --------------------------------------------------------

    @Test
    fun crossingSeveralThresholdsSendsOnlyTheHighestOnce() {
        val used = (3.2 * gb).toLong() // 80% of 4 GB
        val first = NotificationPolicy.evaluate(used, 4 * gb, setOf(50, 80, 90, 100), emptySet())
        assertEquals(80, first.alertThreshold)
        assertEquals(setOf(50, 80), first.crossed)

        val second = NotificationPolicy.evaluate(used, 4 * gb, setOf(50, 80, 90, 100), first.crossed)
        assertNull(second.alertThreshold)
    }

    @Test
    fun jumpingToLimitAlertsAt100Only() {
        val d = NotificationPolicy.evaluate(4 * gb, 4 * gb, setOf(80, 100), emptySet())
        assertEquals(100, d.alertThreshold)
        assertEquals(setOf(80, 100), d.crossed)
    }

    @Test
    fun belowAllThresholdsNothingIsSent() {
        val d = NotificationPolicy.evaluate(gb, 4 * gb, setOf(50, 80), emptySet())
        assertNull(d.alertThreshold)
        assertEquals(emptySet<Int>(), d.crossed)
    }

    @Test
    fun percentIsZeroForNonPositiveLimit() {
        assertEquals(0, NotificationPolicy.percentUsed(gb, 0L))
    }

    // ---- History summaries -------------------------------------------------------

    @Test
    fun historySummaryCountsWeekMonthAverageAndHighest() {
        val end = LocalDate.of(2026, 11, 18)
        val points = listOf(
            DailyPoint(end, 1_000L, gb),
            DailyPoint(end.minusDays(3), 3_000L, gb),
            DailyPoint(end.minusDays(10), 5_000L, gb),  // outside week, inside month
            DailyPoint(end.minusDays(40), 9_000L, gb),  // outside month
        )
        val s = HistoryStats.summarize(points, end)
        assertEquals(4_000L, s.weeklyBytes)
        assertEquals(9_000L, s.monthlyBytes)
        assertEquals(9_000L, s.highest?.usedBytes)
        assertEquals(4_500L, s.averageBytes)
        assertEquals(4, s.daysRecorded)
    }
}
