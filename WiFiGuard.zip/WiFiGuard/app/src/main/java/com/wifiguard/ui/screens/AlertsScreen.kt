package com.wifiguard.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.core.content.ContextCompat
import com.wifiguard.domain.WifiGuardSettings
import com.wifiguard.ui.components.GlassCard
import com.wifiguard.ui.theme.DangerRose
import com.wifiguard.ui.theme.TextMuted

private val PRESET_THRESHOLDS = listOf(50, 60, 70, 80, 90, 100)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AlertsScreen(
    settings: WifiGuardSettings,
    firedToday: Set<Int>,
    onToggleThreshold: (Int) -> Unit,
    onAddThreshold: (Int) -> Unit,
    onSetEnabled: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    var permitted by remember { mutableStateOf(notificationsPermitted(context)) }
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { granted -> permitted = granted }

    var customText by remember { mutableStateOf("") }
    var customError by remember { mutableStateOf<String?>(null) }
    val options = (PRESET_THRESHOLDS + settings.thresholdPercents).toSortedSet().toList()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text("Alerts", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)

        GlassCard(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Enable notifications", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Get an alert when a threshold is crossed.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextMuted,
                    )
                }
                Switch(checked = settings.notificationsEnabled, onCheckedChange = onSetEnabled)
            }
        }

        if (!permitted && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            GlassCard(Modifier.fillMaxWidth()) {
                Text(
                    "Notification permission is off",
                    style = MaterialTheme.typography.titleMedium,
                    color = DangerRose,
                )
                Text(
                    "Android needs your permission before WiFiGuard can show alerts.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextMuted,
                )
                Button(onClick = { permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) }) {
                    Text("Allow notifications")
                }
            }
        }

        GlassCard(Modifier.fillMaxWidth()) {
            Text("Warning thresholds", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Text(
                "Each threshold alerts once per daily period. Several crossed at once give one alert.",
                style = MaterialTheme.typography.bodySmall,
                color = TextMuted,
            )
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                options.forEach { percent ->
                    FilterChip(
                        selected = percent in settings.thresholdPercents,
                        onClick = { onToggleThreshold(percent) },
                        label = { Text("$percent%") },
                    )
                }
            }
            Spacer(Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = customText,
                    onValueChange = { customText = it.filter(Char::isDigit).take(3) },
                    label = { Text("Custom %") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f),
                )
                Spacer(Modifier.width(12.dp))
                Button(onClick = {
                    val value = customText.toIntOrNull()
                    if (value == null || value !in 1..200) {
                        customError = "Enter a value from 1 to 200"
                    } else {
                        onAddThreshold(value)
                        customText = ""
                        customError = null
                    }
                }) { Text("Add") }
            }
            customError?.let {
                Text(it, style = MaterialTheme.typography.bodySmall, color = DangerRose)
            }
        }

        GlassCard(Modifier.fillMaxWidth()) {
            Text("Sent this period", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            if (firedToday.isEmpty()) {
                Text("No alerts yet in the current period.", style = MaterialTheme.typography.bodyMedium, color = TextMuted)
            } else {
                firedToday.sorted().forEach { percent ->
                    Text("Crossed $percent% of the daily limit", style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}

private fun notificationsPermitted(context: android.content.Context): Boolean =
    Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
        ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
        PackageManager.PERMISSION_GRANTED
