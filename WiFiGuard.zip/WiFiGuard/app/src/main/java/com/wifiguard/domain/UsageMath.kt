package com.wifiguard.domain

import java.time.Instant
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.util.Locale

/**
 * Pure time arithmetic for daily periods. Every period boundary is derived from the
 * clock and the configured reset time, never from stored counters, so restarts,
 * missed workers and time-zone changes cannot cause a double reset.
 */
object PeriodCalculator {

    fun window(nowMs: Long, reset: ResetTime, zone: ZoneId): PeriodWindow {
        val local = Instant.ofEpochMilli(nowMs).atZone(zone)
        val startDate = if (local.toLocalTime() < reset.toLocalTime()) {
            local.toLocalDate().minusDays(1)
        } else {
            local.toLocalDate()
        }
        return PeriodWindow(
            key = startDate.toString(),
            startMs = startOf(startDate, reset, zone),
            nextResetMs = startOf(startDate.plusDays(1), reset, zone),
        )
    }

    /** Epoch millis of the reset moment on [date] in [zone]. */
    fun startOf(date: LocalDate, reset: ResetTime, zone: ZoneId): Long =
        date.atTime(reset.toLocalTime()).atZone(zone).toInstant().toEpochMilli()

    private fun ResetTime.toLocalTime(): LocalTime = LocalTime.of(hour, minute)
}

object NotificationPolicy {

    /**
     * [alertThreshold] is the single highest newly crossed threshold (one alert, not a burst).
     * [crossed] is every threshold currently exceeded; the caller stores these as fired.
     */
    data class Decision(val alertThreshold: Int?, val crossed: Set<Int>)

    fun percentUsed(usedBytes: Long, limitBytes: Long): Int =
        if (limitBytes <= 0L) 0 else ((usedBytes * 100L) / limitBytes).toInt()

    fun evaluate(
        usedBytes: Long,
        limitBytes: Long,
        thresholds: Set<Int>,
        alreadyFired: Set<Int>,
    ): Decision {
        val pct = percentUsed(usedBytes, limitBytes)
        val crossed = thresholds.filter { pct >= it }.toSet()
        val fresh = crossed - alreadyFired
        return Decision(alertThreshold = fresh.maxOrNull(), crossed = crossed)
    }
}

data class HistorySummary(
    val weeklyBytes: Long,
    val monthlyBytes: Long,
    val highest: DailyPoint?,
    val averageBytes: Long,
    val daysRecorded: Int,
)

object HistoryStats {

    /** Weekly = last 7 days ending [endDate]; monthly = last 30 days; average = all recorded days. */
    fun summarize(points: List<DailyPoint>, endDate: LocalDate): HistorySummary {
        val weekStart = endDate.minusDays(6)
        val monthStart = endDate.minusDays(29)
        val weekly = points.filter { it.date in weekStart..endDate }.sumOf { it.usedBytes }
        val monthly = points.filter { it.date in monthStart..endDate }.sumOf { it.usedBytes }
        val average = if (points.isEmpty()) 0L else points.sumOf { it.usedBytes } / points.size
        return HistorySummary(
            weeklyBytes = weekly,
            monthlyBytes = monthly,
            highest = points.maxByOrNull { it.usedBytes },
            averageBytes = average,
            daysRecorded = points.size,
        )
    }
}

object ByteFormat {
    private const val MB = 1024.0 * 1024.0
    private const val GB = MB * 1024.0

    fun format(bytes: Long): String {
        val b = bytes.toDouble()
        return when {
            b >= GB -> String.format(Locale.getDefault(), "%.2f GB", b / GB)
            b >= MB -> String.format(Locale.getDefault(), "%.0f MB", b / MB)
            else -> String.format(Locale.getDefault(), "%.0f KB", b / 1024.0)
        }
    }
}
