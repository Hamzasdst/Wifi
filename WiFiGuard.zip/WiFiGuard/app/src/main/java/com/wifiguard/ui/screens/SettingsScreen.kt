package com.wifiguard.ui.screens

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.wifiguard.domain.DataUnit
import com.wifiguard.domain.WifiGuardSettings
import com.wifiguard.ui.components.GlassCard
import com.wifiguard.ui.components.formatAmount
import com.wifiguard.ui.theme.DangerRose
import com.wifiguard.ui.theme.TextMuted

@Composable
fun SettingsScreen(
    settings: WifiGuardSettings,
    hasUsageAccess: Boolean,
    onSaveLimit: (Double, DataUnit) -> Unit,
    onSaveResetTime: (Int, Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current

    var amountText by remember(settings.limitAmount, settings.limitUnit) {
        mutableStateOf(formatAmount(settings.limitAmount))
    }
    var unit by remember(settings.limitUnit) { mutableStateOf(settings.limitUnit) }
    var limitError by remember { mutableStateOf<String?>(null) }

    var hourText by remember(settings.resetTime) { mutableStateOf("%02d".format(settings.resetTime.hour)) }
    var minuteText by remember(settings.resetTime) { mutableStateOf("%02d".format(settings.resetTime.minute)) }
    var resetError by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text("Settings", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)

        GlassCard(Modifier.fillMaxWidth()) {
            Text("Daily Wi-Fi limit", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            OutlinedTextField(
                value = amountText,
                onValueChange = { amountText = it.filter { c -> c.isDigit() || c == '.' } },
                label = { Text("Amount") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier.fillMaxWidth(),
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DataUnit.entries.forEach { option ->
                    FilterChip(
                        selected = unit == option,
                        onClick = { unit = option },
                        label = { Text(option.label) },
                    )
                }
            }
            limitError?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = DangerRose) }
            Button(onClick = {
                val value = amountText.toDoubleOrNull()
                val maxAmount = if (unit == DataUnit.GB) 1024.0 else 10_240.0
                when {
                    value == null || value <= 0.0 -> limitError = "Enter a positive number"
                    value > maxAmount -> limitError = "Limit is too large for ${unit.label}"
                    else -> {
                        limitError = null
                        onSaveLimit(value, unit)
                    }
                }
            }) { Text("Save limit") }
        }

        GlassCard(Modifier.fillMaxWidth()) {
            Text("Daily reset time", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Text(
                "Usage restarts at this local time each day. Default is midnight.",
                style = MaterialTheme.typography.bodySmall,
                color = TextMuted,
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = hourText,
                    onValueChange = { hourText = it.filter(Char::isDigit).take(2) },
                    label = { Text("Hour") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f),
                )
                Spacer(Modifier.width(12.dp))
                OutlinedTextField(
                    value = minuteText,
                    onValueChange = { minuteText = it.filter(Char::isDigit).take(2) },
                    label = { Text("Minute") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f),
                )
            }
            resetError?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = DangerRose) }
            Button(onClick = {
                val h = hourText.toIntOrNull()
                val m = minuteText.toIntOrNull()
                if (h == null || m == null || h !in 0..23 || m !in 0..59) {
                    resetError = "Hour must be 0–23 and minute 0–59"
                } else {
                    resetError = null
                    onSaveResetTime(h, m)
                }
            }) { Text("Save reset time") }
        }

        GlassCard(Modifier.fillMaxWidth()) {
            Text("Permissions & reliability", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Text(
                if (hasUsageAccess) "Usage access: granted" else "Usage access: not granted",
                style = MaterialTheme.typography.bodyMedium,
                color = if (hasUsageAccess) MaterialTheme.colorScheme.onSurface else DangerRose,
            )
            OutlinedButton(onClick = {
                context.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            }) { Text("Usage access settings") }
            Text(
                "Set WiFiGuard to Unrestricted or Not optimised in battery settings so Android " +
                    "does not delay background checks.",
                style = MaterialTheme.typography.bodySmall,
                color = TextMuted,
            )
            OutlinedButton(onClick = {
                context.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }) { Text("Battery settings") }
        }
    }
}
