package com.wifiguard.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.wifiguard.ui.components.GlassCard
import com.wifiguard.ui.theme.TextMuted

@Composable
fun AboutScreen(modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text("About WiFiGuard", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Version 1.0.0", style = MaterialTheme.typography.bodyMedium, color = TextMuted)

        GlassCard(Modifier.fillMaxWidth()) {
            Text("What it measures", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Text(
                "Wi-Fi bytes only (received and sent on the Wi-Fi interface), read from Android's " +
                    "NetworkStatsManager. Mobile data is never queried or counted.",
                style = MaterialTheme.typography.bodyMedium,
            )
        }

        GlassCard(Modifier.fillMaxWidth()) {
            Text("Known limits", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Text(
                "• Android publishes network statistics in buckets with a delay, so totals are not " +
                    "real-time.\n" +
                    "• VPN overhead is counted as encrypted traffic on the Wi-Fi interface.\n" +
                    "• Figures depend on how long the device keeps network history.\n" +
                    "• Some manufacturers restrict background work; WiFiGuard cannot override that.",
                style = MaterialTheme.typography.bodyMedium,
                color = TextMuted,
            )
        }

        GlassCard(Modifier.fillMaxWidth()) {
            Text("Privacy", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Text(
                "No accounts, no servers, no analytics, no ads. All history stays on this device. " +
                    "The app does not request the Internet permission.",
                style = MaterialTheme.typography.bodyMedium,
                color = TextMuted,
            )
        }
    }
}
