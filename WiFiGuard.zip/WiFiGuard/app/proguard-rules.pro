# Room, WorkManager and DataStore ship their own consumer rules.
# Add keep rules here only if you introduce reflection-based code.
