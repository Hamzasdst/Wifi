package com.wifiguard.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.wifiguard.WiFiGuardApp
import com.wifiguard.domain.DailyPoint
import com.wifiguard.domain.DataUnit
import com.wifiguard.domain.HistoryStats
import com.wifiguard.domain.HistorySummary
import com.wifiguard.domain.ResetTime
import com.wifiguard.domain.UsageSnapshot
import com.wifiguard.domain.WifiGuardSettings
import com.wifiguard.ui.components.ChartBar
import com.wifiguard.ui.components.SHORT_FORMAT
import com.wifiguard.ui.components.WEEKDAY_FORMAT
import com.wifiguard.work.UsageWorkScheduler
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.time.LocalDate

data class DashboardState(
    val settings: WifiGuardSettings = WifiGuardSettings(),
    val snapshot: UsageSnapshot? = null,
    val recent: List<ChartBar> = emptyList(),
)

data class HistoryState(
    val selected: LocalDate = LocalDate.now(),
    val canGoForward: Boolean = false,
    val selectedPoint: DailyPoint? = null,
    val summary: HistorySummary? = null,
    val limitBytes: Long = WifiGuardSettings().limitBytes,
    val chart: List<ChartBar> = emptyList(),
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val container = (application as WiFiGuardApp).container
    private val settingsStore = container.settingsStore
    private val repository = container.repository

    private val snapshot = MutableStateFlow<UsageSnapshot?>(null)

    /** null means "today", so the selection follows the day rollover. */
    private val selectedDay = MutableStateFlow<LocalDate?>(null)

    val settings: StateFlow<WifiGuardSettings> = settingsStore.settings
        .stateIn(viewModelScope, SharingStarted.Eagerly, WifiGuardSettings())

    val dashboard: StateFlow<DashboardState> = combine(
        settings,
        repository.observeHistory(),
        snapshot,
    ) { s, points, snap ->
        DashboardState(settings = s, snapshot = snap, recent = recentBars(points, snap))
    }.stateIn(viewModelScope, SharingStarted.Eagerly, DashboardState())

    val history: StateFlow<HistoryState> = combine(
        settings,
        repository.observeHistory(),
        snapshot,
        selectedDay,
    ) { s, points, snap, selected ->
        val today = todayKey(snap)
        val day = selected ?: today
        val byDate = points.associateBy { it.date }
        HistoryState(
            selected = day,
            canGoForward = day < today,
            selectedPoint = byDate[day],
            summary = HistoryStats.summarize(points, today),
            limitBytes = snap?.limitBytes ?: s.limitBytes,
            chart = (13 downTo 0).map { back ->
                val d = day.minusDays(back.toLong())
                ChartBar(d.format(SHORT_FORMAT), byDate[d]?.usedBytes ?: 0L)
            },
        )
    }.stateIn(viewModelScope, SharingStarted.Eagerly, HistoryState())

    /** Thresholds already alerted on in the current period. */
    val firedToday: StateFlow<Set<Int>> = combine(settingsStore.fired, snapshot) { fired, snap ->
        if (snap != null && fired.period == snap.window.key) fired.thresholds else emptySet()
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptySet())

    init {
        viewModelScope.launch {
            while (isActive) {
                refresh()
                delay(REFRESH_MS)
            }
        }
    }

    fun refreshNow() {
        viewModelScope.launch { refresh() }
    }

    private suspend fun refresh() {
        runCatching { container.usageMonitor.runCheck() }
            .onSuccess { snapshot.value = it }
    }

    fun shiftDay(delta: Long) {
        val today = todayKey(snapshot.value)
        val current = selectedDay.value ?: today
        val next = current.plusDays(delta)
        selectedDay.value = if (next >= today) null else next
    }

    fun saveLimit(amount: Double, unit: DataUnit) =
        updateSettings { it.copy(limitAmount = amount, limitUnit = unit) }

    fun saveResetTime(hour: Int, minute: Int) =
        updateSettings { it.copy(resetTime = ResetTime(hour, minute)) }

    fun setNotificationsEnabled(enabled: Boolean) =
        updateSettings { it.copy(notificationsEnabled = enabled) }

    fun toggleThreshold(percent: Int) = updateSettings { s ->
        val next = if (percent in s.thresholdPercents) {
            s.thresholdPercents - percent
        } else {
            s.thresholdPercents + percent
        }
        s.copy(thresholdPercents = next)
    }

    fun addThreshold(percent: Int) =
        updateSettings { it.copy(thresholdPercents = it.thresholdPercents + percent) }

    private fun updateSettings(transform: (WifiGuardSettings) -> WifiGuardSettings) {
        viewModelScope.launch {
            settingsStore.update(transform)
            val reset = settingsStore.currentSettings().resetTime
            UsageWorkScheduler.scheduleReset(getApplication(), reset)
            refresh()
        }
    }

    private fun recentBars(points: List<DailyPoint>, snap: UsageSnapshot?): List<ChartBar> {
        val today = todayKey(snap)
        val byDate = points.associateBy { it.date }
        return (6 downTo 0).map { back ->
            val d = today.minusDays(back.toLong())
            ChartBar(d.format(WEEKDAY_FORMAT), byDate[d]?.usedBytes ?: 0L)
        }
    }

    private fun todayKey(snap: UsageSnapshot?): LocalDate =
        snap?.window?.key?.let { LocalDate.parse(it) } ?: LocalDate.now()

    private companion object {
        const val REFRESH_MS = 60_000L
    }
}
