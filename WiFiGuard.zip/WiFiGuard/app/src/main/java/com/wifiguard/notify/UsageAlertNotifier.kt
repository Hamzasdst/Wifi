package com.wifiguard.notify

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.wifiguard.domain.ByteFormat

class UsageAlertNotifier(private val context: Context) {

    fun createChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Wi-Fi usage alerts",
            NotificationManager.IMPORTANCE_HIGH,
        ).apply {
            description = "Warnings when daily Wi-Fi usage crosses your thresholds"
        }
        context.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    /**
     * Shows one alert for [thresholdPercent]. Returns false when nothing was shown
     * (permission denied or notifications blocked), so the caller can retry later.
     * The notification id is the threshold, so the same alert replaces itself instead of stacking.
     */
    fun showUsageAlert(thresholdPercent: Int, usedBytes: Long, limitBytes: Long): Boolean {
        if (!canPost()) return false

        val remaining = (limitBytes - usedBytes).coerceAtLeast(0L)
        val title = if (usedBytes >= limitBytes) {
            "WiFiGuard – Daily Wi-Fi limit reached"
        } else {
            "WiFiGuard – Daily Wi-Fi Warning"
        }
        val body = "You have used ${ByteFormat.format(usedBytes)} of your " +
            "${ByteFormat.format(limitBytes)} daily allowance. " +
            "You have ${ByteFormat.format(remaining)} remaining."

        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_warning)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)

        context.packageManager.getLaunchIntentForPackage(context.packageName)?.let { intent ->
            val pending = PendingIntent.getActivity(
                context,
                0,
                intent,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            )
            builder.setContentIntent(pending)
        }

        return try {
            NotificationManagerCompat.from(context).notify(thresholdPercent, builder.build())
            true
        } catch (e: SecurityException) {
            false
        }
    }

    private fun canPost(): Boolean {
        val permitted = Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS,
            ) == PackageManager.PERMISSION_GRANTED
        return permitted && NotificationManagerCompat.from(context).areNotificationsEnabled()
    }

    companion object {
        const val CHANNEL_ID = "wifiguard_usage_alerts"
    }
}
